// JavaScript to simulate order processing and display the result

function placeOrder() {
    // Simulate the order process with a random success or failure
    let orderSuccessful = Math.random() > 0.5; // Randomly decide if the order is successful or not

    const orderStatusElement = document.getElementById('order-status');
    const orderDetailsElement = document.getElementById('order-details');

    if (orderSuccessful) {
        orderStatusElement.textContent = 'Order Confirmed';
        orderStatusElement.className = 'order-status success';

        // Calculate a delivery date (e.g., 5 days from now)
        let deliveryDate = new Date();
        deliveryDate.setDate(deliveryDate.getDate() + 5);
        let options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };

        orderDetailsElement.innerHTML = `
            <p>Thank you for your purchase! Your order has been successfully placed.</p>
            <p>Expected Delivery Date: ${deliveryDate.toLocaleDateString('en-US', options)}</p>
            <p>Order Number: #${Math.floor(Math.random() * 1000000)}</p>
        `;
    } else {
        orderStatusElement.textContent = 'Order Failed';
        orderStatusElement.className = 'order-status failure';

        orderDetailsElement.innerHTML = `
            <p>Unfortunately, your order could not be processed at this time.</p>
            <p>Please check your payment details and try again.</p>
            <p>If the problem persists, contact our support team.</p>
        `;
    }
}

// Function to show modal with product details
function showDetails(card) {
    const modal = document.getElementById('modal');
    const title = card.querySelector('h3').innerText;
    const description = card.querySelector('p').innerText;

    document.getElementById('modal-title').innerText = title;
    document.getElementById('modal-description').innerText = description;

    modal.style.display = 'flex';
}

// Function to close modal
function closeModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'none';
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById('modal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}

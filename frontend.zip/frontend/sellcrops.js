document.getElementById('productForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const productName = document.getElementById('productName').value;
    const description = document.getElementById('description').value;
    const pricePerKg = document.getElementById('pricePerKg').value;
    const pricePerQuintal = document.getElementById('pricePerQuintal').value;
    const imageUpload = document.getElementById('imageUpload').files[0];
    const quantity = document.getElementById('quantity').value;
    const category = document.getElementById('category').value;
    const location = document.getElementById('location').value;
    const sellerName = document.getElementById('sellerName').value;
    const sellerDescription = document.getElementById('sellerDescription').value;

    if (!productName || !description || !pricePerKg || !pricePerQuintal || !imageUpload || !quantity || !category || !location || !sellerName || !sellerDescription) {
        alert("Please fill in all fields and upload an image.");
        return;
    }

    alert("Product submitted successfully!");
});

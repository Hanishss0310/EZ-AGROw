<button onclick="location.href='hire.html?name=John Doe'" class="hire-btn">Hire Him</button>
